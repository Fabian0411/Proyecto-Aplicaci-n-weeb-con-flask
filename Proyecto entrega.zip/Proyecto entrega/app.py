from flask import Flask, render_template, request, redirect, url_for, g
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///{}'.format(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'nombre_de_tu_base_de_datos.db'))
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'tu_clave_secreta'

db = SQLAlchemy(app)
login_manager = LoginManager(app)

class Usuario(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(50))
    edad = db.Column(db.Integer)
    estatura = db.Column(db.Float)
    correo = db.Column(db.String(100), unique=True)
    contraseña = db.Column(db.String(100))

@login_manager.user_loader
def cargar_usuario(usuario_id):
    return Usuario.query.get(int(usuario_id))




@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        nombre = request.form['nombre']
        edad = request.form['edad']
        estatura = request.form['estatura']
        sexo = request.form['sexo']
        correo = request.form['correo']
        contrasena = request.form['contrasena']

        nuevo_usuario = Usuario(nombre=nombre, edad=edad, estatura=estatura, sexo=sexo, correo=correo, contraseña=contrasena)
        db.session.add(nuevo_usuario)
        db.session.commit()

        return redirect(url_for('landing_pageI'))

    return render_template('landing_pageR.html')

@app.route('/verificar_usuario', methods=['POST'])
def verificar_usuario():
    correo = request.form['correo']
    contrasena = request.form['contrasena']

    usuario = Usuario.query.filter_by(correo=correo, contraseña=contrasena).first()

    if usuario:
        # Usuario encontrado, inicia sesión
        login_user(usuario)
        return redirect(url_for('home_page'))
    else:
        # Las credenciales no son válidas, puedes mostrar un mensaje o redirigir a otra página
        return render_template('landing_pageI.html', mensaje_error="Credenciales no válidas")
# Inicializar la base de datos directamente en app.py
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)
